
<?php echo CHtml::encode($message); ?>
