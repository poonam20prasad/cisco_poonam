<?php

/**
 * This is the model class for table "tblapiusers".
 *
 * The followings are the available columns in table 'tblapiusers':
 * @property integer $UserIDAPI
 * @property string $Username
 * @property string $Password
 * @property string $APIKey
 * @property integer $Status
 */
class Tblapiusers extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tblapiusers';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('Status', 'numerical', 'integerOnly'=>true),
			array('Username, Password, APIKey', 'length', 'max'=>100),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('UserIDAPI, Username, Password, APIKey, Status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'UserIDAPI' => 'User Idapi',
			'Username' => 'Username',
			'Password' => 'Password',
			'APIKey' => 'Apikey',
			'Status' => 'Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('UserIDAPI',$this->UserIDAPI);
		$criteria->compare('Username',$this->Username,true);
		$criteria->compare('Password',$this->Password,true);
		$criteria->compare('APIKey',$this->APIKey,true);
		$criteria->compare('Status',$this->Status);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Tblapiusers the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        public function authenticate($username, $password)
        {
            $data = NULL;
            $query="SELECT * FROM `tblapiusers` WHERE `Username` LIKE '$username' AND `Password` LIKE '$password' AND `Status` = 1 ";
            $data = Yii::app()->db->createCommand($query)->queryAll();
            
            if($data!=NULL && !empty($data[0]))
            {
                return $data[0]['UserIDAPI'];
            }
            else
            {
                return FALSE;
            }
        }
        
        public function authenticatekey($key)
        {
            $data = NULL;
            $query="SELECT * FROM `tblapiusers` WHERE `APIKey` LIKE '$key' AND `Status` = 1 ";
            $data = Yii::app()->db->createCommand($query)->queryAll();
            
            if($data!=NULL && !empty($data[0]))
            {
                return $data[0]['UserIDAPI'];
            }
            else
            {
                return FALSE;
            }
        }
        
        public function geturl()
        {
            if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
            {
                $link = "https"; 
            }
                
            else
            {
                $link = "http"; 
            }    
            
            $link .= "://"; 
            $link .= $_SERVER['HTTP_HOST']; 
            $link .= $_SERVER['REQUEST_URI']; 
            
            $b = explode('r=', $link);
            
            if(isset($b[1]))
            {
                return $b[1]; 
            }
            else
            {
                return $link;
            }
            
        }
        
        public function logapi($userid, $data, $response)
        {
            
            $model = new TblAPILogs();
            $model->APIUser = $userid;
            $model->RecivedData = json_encode($data);
            $model->Response = $response;
            $model->Url = $this->geturl();
            $model->Status = 1;
            $model->Created = date('Y-m-d H:i:s');
            $model->save();
            
           
        }
}
