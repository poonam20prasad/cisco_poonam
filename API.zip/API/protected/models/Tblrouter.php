<?php

/**
 * This is the model class for table "tblrouter".
 *
 * The followings are the available columns in table 'tblrouter':
 * @property integer $Rid
 * @property string $Sapid
 * @property string $Hostname
 * @property string $Loopback
 * @property string $MacAddress
 * @property string $Type
 * @property integer $Status
 */
class Tblrouter extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tblrouter';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('Status', 'numerical', 'integerOnly'=>true),
			array('Sapid', 'length', 'max'=>18),
			array('Hostname', 'length', 'max'=>14),
			array('Loopback', 'length', 'max'=>15),
			array('MacAddress', 'length', 'max'=>17),
			array('Type', 'length', 'max'=>3),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('Rid, Sapid, Hostname, Loopback, MacAddress, Type, Status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'Rid' => 'Rid',
			'Sapid' => 'Sapid',
			'Hostname' => 'Hostname',
			'Loopback' => 'Loopback',
			'MacAddress' => 'Mac Address',
			'Type' => 'Type',
			'Status' => 'Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('Rid',$this->Rid);
		$criteria->compare('Sapid',$this->Sapid,true);
		$criteria->compare('Hostname',$this->Hostname,true);
		$criteria->compare('Loopback',$this->Loopback,true);
		$criteria->compare('MacAddress',$this->MacAddress,true);
		$criteria->compare('Type',$this->Type,true);
		$criteria->compare('Status',$this->Status);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Tblrouter the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	public function deleterouter($ip)
	{
		$connection = Yii::app()->db;
		$query="UPDATE `tblrouter` SET `Status`=2 where `Loopback`='".$ip."' ";
		$command=$connection->createCommand($query);
		if($command->execute()){
			$msg="Router updated successfully";
			return $msg;
		}	
		
	}
	
	public function generateSapid($length=18)
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		
		$query = "SELECT * FROM `tblrouter` WHERE `Sapid` LIKE '$randomString' and Status=1 ";
		$data = Yii::app()->db->createCommand($query)->queryRow();
		
		if($data!=NULL){
			return self::generateSapid(18);
		}
		else {
			return $randomString;
		}
		
	}
	
	public function generatehostname($length=14)
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		
		$query = "SELECT * FROM `tblrouter` WHERE `Hostname` LIKE '$randomString' and Status=1 ";
		$data = Yii::app()->db->createCommand($query)->queryRow();
		
		if($data!=NULL){
			return self::generatehostname(14);
		}
		else {
			return $randomString;
		}
		
	}
	
	
	public function generatemacaddress($length=17)
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		
		$query = "SELECT * FROM `tblrouter` WHERE `MacAddress` LIKE '$randomString' and Status=1 ";
		$data = Yii::app()->db->createCommand($query)->queryRow();
		
		if($data!=NULL){
			return self::generatemacaddress(17);
		}
		else {
			return $randomString;
		}
		
	}
	
	public function generateip()
	{
		//$ip=long2ip(rand(0, "4294967295"));
		$ip = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);
		$query = "SELECT * FROM `tblrouter` WHERE `Loopback` LIKE '$ip' and Status=1 ";
		$data = Yii::app()->db->createCommand($query)->queryRow();
		if($data!=NULL){
			return self::generateip();
		}
		else {
			return $ip;
		}	

	}
	
	
}
